/*  SISTEMA DE RIEGO AUTOMATIZADO - VERSIÓN FINAL  */

#include "main.h"
#include <stdio.h>
#include <string.h>

ADC_HandleTypeDef hadc1;
UART_HandleTypeDef huart2;

//  CONFIGURACIÓN CALIBRADA
#define DRY_VALUE           4095    // Sondas al aire (completamente seco)
#define WET_VALUE           1850    // Sondas en agua (completamente húmedo)
#define DRY_THRESHOLD       3100    // Activar riego cuando ADC > 3100
#define WET_THRESHOLD       2500    // Parar riego cuando ADC < 2500
#define PUMP_TIME           4000    // Riego por 4 segundos
#define READ_INTERVAL       2000    // Leer sensor cada 2 segundos
#define CHECK_INTERVAL      8000    // Evaluar riego cada 8 segundos

//  LÓGICA DEL RELAY EN NC (Normal: HIGH=ON, LOW=OFF)
#define PUMP_ON()   HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5, GPIO_PIN_SET)    // HIGH = ON
#define PUMP_OFF()  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5, GPIO_PIN_RESET)  // LOW = OFF

typedef struct {
    uint16_t adc_raw;
    float humidity_percent;
    uint8_t is_dry;
    uint8_t pump_active;
    uint32_t last_read_time;
    uint32_t last_check_time;
    uint32_t pump_start_time;
    uint32_t total_irrigations;
} IrrigationSystem_t;

IrrigationSystem_t irrigation;

void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_ADC1_Init(void);
static void MX_USART2_UART_Init(void);

uint16_t Read_Sensor(void)
{
    // Leer múltiples muestras para mayor estabilidad
    uint32_t sum = 0;
    for(int i = 0; i < 3; i++) {
        HAL_ADC_Start(&hadc1);
        HAL_ADC_PollForConversion(&hadc1, 100);
        sum += HAL_ADC_GetValue(&hadc1);
        HAL_ADC_Stop(&hadc1);
        HAL_Delay(5);
    }
    return (uint16_t)(sum / 3);
}

float Calculate_Humidity(uint16_t adc_value)
{
    if (adc_value >= DRY_VALUE) {
        return 0.0;   // 0% humedad (aire libre)
    } else if (adc_value <= WET_VALUE) {
        return 100.0; // 100% humedad (en agua)
    } else {
        // Conversión lineal: mayor ADC = menor humedad
        float humidity = 100.0 - ((float)(adc_value - WET_VALUE) / (DRY_VALUE - WET_VALUE)) * 100.0;
        return (humidity < 0.0) ? 0.0 : (humidity > 100.0) ? 100.0 : humidity;
    }
}

void Send_Status_Beautiful(void)
{
    uint32_t total_seconds = HAL_GetTick() / 1000;
    uint32_t hours = total_seconds / 3600;
    uint32_t minutes = (total_seconds % 3600) / 60;
    uint32_t seconds = total_seconds % 60;

    char buffer[300];

    //  Formato
    printf(buffer, sizeof(buffer),
        "\r\n┌─────── 🌱 SISTEMA DE RIEGO 🌱 ───────┐\r\n"
        "│  Tiempo: %02lu:%02lu:%02lu                  │\r\n"
        "│  ADC Raw: %-4d                      │\r\n"
        "│ 💧 Humedad: %5.1f%%                     │\r\n"
        "│  Estado: %-15s           │\r\n"
        "│ ⚡ Bomba:  %-15s           │\r\n"
        "│  Riegos: %-4lu                      │\r\n"
        "└──────────────────────────────────────────┘\r\n\r\n",
        hours, minutes, seconds,
        irrigation.adc_raw,
        irrigation.humidity_percent,
        irrigation.is_dry ? " SECO" : " HÚMEDO",
        irrigation.pump_active ? " REGANDO" : " APAGADA",
        irrigation.total_irrigations
    );

    HAL_UART_Transmit(&huart2, (uint8_t*)buffer, strlen(buffer), 2000);
}

void Send_Simple_Status(void)
{
    uint32_t seconds = HAL_GetTick() / 1000;
    char buffer[120];

    // 📱 Formato simple pero informativo
    printf(buffer, sizeof(buffer),
        "[%04lu s] ADC:%4d | H:%5.1f%% | %s | Bomba:%s | Riegos:%lu\r\n",
        seconds,
        irrigation.adc_raw,
        irrigation.humidity_percent,
        irrigation.is_dry ? "SECO " : "HUMEDO",
        irrigation.pump_active ? "ON " : "OFF",
        irrigation.total_irrigations
    );

    HAL_UART_Transmit(&huart2, (uint8_t*)buffer, strlen(buffer), 1000);
}

void Process_Irrigation(void)
{
    uint32_t current_time = HAL_GetTick();

    //  Verificar si necesita riego cada CHECK_INTERVAL
    if (current_time - irrigation.last_check_time >= CHECK_INTERVAL)
    {
        irrigation.last_check_time = current_time;

        //  INICIAR RIEGO: Si está seco y bomba apagada
        if (irrigation.adc_raw > DRY_THRESHOLD && !irrigation.pump_active)
        {
            PUMP_ON();
            irrigation.pump_active = 1;
            irrigation.pump_start_time = current_time;
            irrigation.total_irrigations++;

            char msg[] = "\r\n ¡INICIANDO RIEGO AUTOMÁTICO! \r\n"
                        " Suelo detectado como seco\r\n"
                        " Bomba activada por 4 segundos\r\n\r\n";
            HAL_UART_Transmit(&huart2, (uint8_t*)msg, strlen(msg), 1500);
        }

        //  PARAR RIEGO: Si hay suficiente humedad
        else if (irrigation.adc_raw < WET_THRESHOLD && irrigation.pump_active)
        {
            PUMP_OFF();
            irrigation.pump_active = 0;

            char msg[] = "\r\n✅ RIEGO DETENIDO - HUMEDAD SUFICIENTE ✅\r\n\r\n";
            HAL_UART_Transmit(&huart2, (uint8_t*)msg, strlen(msg), 1000);
        }
    }

    //  Control de tiempo máximo de riego (seguridad)
    if (irrigation.pump_active &&
        (current_time - irrigation.pump_start_time >= PUMP_TIME))
    {
        PUMP_OFF();
        irrigation.pump_active = 0;

        char msg[] = "\r\n RIEGO COMPLETADO - TIEMPO CUMPLIDO \r\n\r\n";
        HAL_UART_Transmit(&huart2, (uint8_t*)msg, strlen(msg), 1000);
    }
}

int main(void)
{
    HAL_Init();
    SystemClock_Config();
    MX_GPIO_Init();
    MX_ADC1_Init();
    MX_USART2_UART_Init();

    //  Inicializar sistema
    memset(&irrigation, 0, sizeof(irrigation));

    //  ASEGURAR BOMBA APAGADA AL INICIO
    PUMP_OFF();

    //  Mensaje de bienvenida
    char welcome[] =
        "\r\n"
        "🌱          SISTEMA DE RIEGO INTELIGENTE          🌱\r\n"
        "\r\n"
        "⚙️  CONFIGURACIÓN:\r\n"
        "    Sensor: Resistivo (2 sondas)\r\n"
        "     Umbral seco: ADC > 3100\r\n"
        "     Umbral húmedo: ADC < 2500\r\n"
        "    Duración riego: 4 segundos\r\n"
        "    Evaluación: cada 8 segundos\r\n"
        "    Relay: NC (HIGH=ON, LOW=OFF)\r\n"
        "\r\n"
        " Sistema iniciado correctamente!\r\n"

    HAL_UART_Transmit(&huart2, (uint8_t*)welcome, strlen(welcome), 3000);

    //  Contador para alternar entre formato bonito y simple
    uint32_t display_counter = 0;

    while (1)
    {
        uint32_t current_time = HAL_GetTick();

        // 📡 Leer sensor cada read_interval
        if (current_time - irrigation.last_read_time >= READ_INTERVAL)
        {
            irrigation.adc_raw = Read_Sensor();
            irrigation.humidity_percent = Calculate_Humidity(irrigation.adc_raw);
            irrigation.is_dry = (irrigation.adc_raw > DRY_THRESHOLD);
            irrigation.last_read_time = current_time;

            display_counter++;
            if (display_counter % 5 == 0) {
                Send_Status_Beautiful();  // Formato bonito cada 10 segundos
            } else {
                Send_Simple_Status();     // Formato simple cada 2 segundos
            }
        }

        //  Procesar lógica de riego
        Process_Irrigation();

        HAL_Delay(100);
    }
}

void SystemClock_Config(void)
{
    RCC_OscInitTypeDef RCC_OscInitStruct = {0};
    RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

    __HAL_RCC_PWR_CLK_ENABLE();
    __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

    RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
    RCC_OscInitStruct.HSIState = RCC_HSI_ON;
    RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
    RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
    RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
    RCC_OscInitStruct.PLL.PLLM = 8;
    RCC_OscInitStruct.PLL.PLLN = 180;
    RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
    RCC_OscInitStruct.PLL.PLLQ = 7;
    RCC_OscInitStruct.PLL.PLLR = 2;

    if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK) {
        Error_Handler();
    }

    if (HAL_PWREx_EnableOverDrive() != HAL_OK) {
        Error_Handler();
    }

    RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                                |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
    RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
    RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
    RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
    RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;

    if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_5) != HAL_OK) {
        Error_Handler();
    }
}

static void MX_ADC1_Init(void)
{
    ADC_ChannelConfTypeDef sConfig = {0};

    hadc1.Instance = ADC1;
    hadc1.Init.ClockPrescaler = ADC_CLOCK_SYNC_PCLK_DIV6;
    hadc1.Init.Resolution = ADC_RESOLUTION_12B;
    hadc1.Init.ScanConvMode = DISABLE;
    hadc1.Init.ContinuousConvMode = DISABLE;
    hadc1.Init.DiscontinuousConvMode = DISABLE;
    hadc1.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;
    hadc1.Init.ExternalTrigConv = ADC_SOFTWARE_START;
    hadc1.Init.DataAlign = ADC_DATAALIGN_RIGHT;
    hadc1.Init.NbrOfConversion = 1;
    hadc1.Init.DMAContinuousRequests = DISABLE;
    hadc1.Init.EOCSelection = ADC_EOC_SINGLE_CONV;

    if (HAL_ADC_Init(&hadc1) != HAL_OK) {
        Error_Handler();
    }

    sConfig.Channel = ADC_CHANNEL_0;
    sConfig.Rank = 1;
    sConfig.SamplingTime = ADC_SAMPLETIME_15CYCLES;

    if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK) {
        Error_Handler();
    }
}

static void MX_USART2_UART_Init(void)
{
    huart2.Instance = USART2;
    huart2.Init.BaudRate = 9600;
    huart2.Init.WordLength = UART_WORDLENGTH_8B;
    huart2.Init.StopBits = UART_STOPBITS_1;
    huart2.Init.Parity = UART_PARITY_NONE;
    huart2.Init.Mode = UART_MODE_TX_RX;
    huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
    huart2.Init.OverSampling = UART_OVERSAMPLING_16;

    if (HAL_UART_Init(&huart2) != HAL_OK) {
        Error_Handler();
    }
}

static void MX_GPIO_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStruct = {0};

    __HAL_RCC_GPIOC_CLK_ENABLE();
    __HAL_RCC_GPIOH_CLK_ENABLE();
    __HAL_RCC_GPIOA_CLK_ENABLE();
    __HAL_RCC_GPIOB_CLK_ENABLE();

    //  Configurar PA5 como output (relay) - INICIAR EN LOW (OFF)
    HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5, GPIO_PIN_RESET);

    GPIO_InitStruct.Pin = GPIO_PIN_5;
    GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

    //  Button
    GPIO_InitStruct.Pin = GPIO_PIN_13;
    GPIO_InitStruct.Mode = GPIO_MODE_IT_FALLING;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);
}

void Error_Handler(void)
{
    __disable_irq();
    while (1) {
        //  En caso de error, asegurar bomba apagada
        PUMP_OFF();
        HAL_Delay(100);
    }
}
